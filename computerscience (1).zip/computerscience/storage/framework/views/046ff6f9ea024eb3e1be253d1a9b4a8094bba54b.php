
<?php $__env->startSection('header', 'Crear Nueva Sesión'); ?>

<?php $__env->startSection('descripcion', 'Llena el siguiente formulario.'); ?>

<?php $__env->startSection('nuevo_concurso'); ?>
<div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">
<div class="container">
	<form action="<?php echo e(route('sesion.store')); ?>" method ="POST" enctype="multipart/form-data" style="display:flex;flex-direction:column;justify-items:center;text-align:center;">
	<?php echo csrf_field(); ?>

		<div class="col-md-6" style="max-width:100%">
		</div>	 
			<label for="enlace_meet">Seleccionar Edicion:</label>
			<div class="form-group">
				<select name="id_programa">
					<?php $__currentLoopData = $all_eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
					<option value="" >
						<?php echo e($evento->hora_inicio); ?> <?php echo e($evento->tema); ?>

					</option>
					<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
			</div>
        
			<div class="form-group">
				<label for="fecha">Fecha</label>
					<input type='date' required="" id="fecha" name='fecha' value="">
					<i  class="glyphicon" style="width: 10px;"></i>
				<label for="hora_inicio">  Hora Inicio</label>
					<input  type='time' id="hora_inicio" name="hora_inicio" >
					<i  class="glyphicon"  style="width: 10px;"></i>
				<label for="hora_final">Hora Final</label>
					<input  type='time' id="hora_final" name="hora_final" >

			</div>	 
			<label for="enlace_meet">Enlace de la reuni&oacute;n</label>
			<div class="form-group">
				<input type="text" placeholder="https://meet.google.com/" required="" id="enlace_meet" size="72"  name='enlace_meet' value="">
				<i  class="glyphicon glyphicon-font"></i>
			</div>
		</div>

	</div>
	<div class="col-md-12 ">
		<center>
            <br><button type="submit" class="about-btn-right">Guardar</button>
		</center>
	</div>
    </form>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.third', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\computerscience\resources\views/sesion/add_evento.blade.php ENDPATH**/ ?>