

<?php $__env->startSection('header', 'Información del Ponente'); ?>


<?php $__env->startSection('info_ponentes'); ?>
<div class="row schedule-item">
    <div class="col-md-2">
        <h4>Ponente:</strong></h4>
    </div>
    <div class="col-md-10">
        <h4><?php echo e($ponente->nombre); ?></h4>
        <h5><strong>Sobre el Ponente:</strong><br><?php echo e($ponente->descripcion); ?></h5>
        <h5><strong>Grado Académico: </strong><time><?php echo e($ponente->grado_academico); ?></time><br>
        <strong>Especialidad: </strong><time><?php echo e($ponente->especialidad); ?></time><br>
        <strong>Correo: </strong><time><?php echo e($ponente->email); ?></time><br>
        <strong>Teléfono: </strong><time><?php echo e($ponente->telefono); ?></time><br></h5>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('ponente.editar', $ponente)); ?>" class="btn btn-outline-info">Editar Ponente</a><br><br>
            <form action="<?php echo e(route('ponente.eliminar', $ponente)); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button type="submit" class="btn btn-outline-danger">Eliminar Ponente</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.secondary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\computerscience\resources\views/ponente/show.blade.php ENDPATH**/ ?>