<h1>
    Registro
</h1>

<form action="<?php echo e(route('participante.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <strong>DNI_persona:</strong>
    <input type="text" name="dni">
    <strong>nombre:</strong>
    <input type="text" name="nombre">
    <strong>email:</strong>
    <input type="text" name="email">
    <strong>password:</strong>
    <input type="text" name="password">
    <strong>universidad:</strong>
    <input type="text" name="universidad">
    <strong>grado:</strong>
    <input type="text" name="grado">
    <button type="submit">Submit</button>
</form><?php /**PATH C:\AppServ\www\computerscience\resources\views/participante/registro.blade.php ENDPATH**/ ?>