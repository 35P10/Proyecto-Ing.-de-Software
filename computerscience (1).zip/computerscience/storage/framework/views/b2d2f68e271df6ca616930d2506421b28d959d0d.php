
<?php $__env->startSection('header', 'Creando Nuevo Evento'); ?>
<?php $__env->startSection('descripcion', 'Elige una de las opciones.'); ?>
<?php $__env->startSection('nuevo_evento_opciones'); ?>
        <br><br>
        <center>
        <a href="<?php echo e(route('participante.create')); ?>" class="about-btn-right">Crear Nueva Ponencia</a>
        </center>
        <br>
        <center>
        <a href="<?php echo e(route('participante.create')); ?>" class="about-btn-right">Crear Nuevo Concurso</a>
        </center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.third', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\computerscience\resources\views/evento/create-options.blade.php ENDPATH**/ ?>