

<?php $__env->startSection('header', 'Eventos'); ?>

<?php $__env->startSection('boton_crear'); ?>
<?php if(auth()->guard()->check()): ?>
<?php if(session('isAdmin')): ?>
    <a href="<?php echo e(route('evento.mostrarOpciones', request()->segment(count(request()->segments())))); ?>" class="about-btn-right"><i  class="glyphicon glyphicon-plus"></i> Nuevo Evento</a>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('detalles_programas'); ?>
<div class="row">
        <div class="col-lg-6">
            <h2>Edición 2020 - Semana de la Computación</h2>
            <p>Descripción</p>
        </div>
        <div class="col-lg-3">
            <h3>Lugar:</h3>
            <p>Universidad Nacional de San Agustin , Arequipa</p>
        </div>
        <div class="col-lg-3">
            <h3>Duración</h3>
            <p>Inicio:<br>10-12 Diciembre</p>
            <p>Fin:<br>10-12 Diciembre</p>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('eventos'); ?>
<?php $__currentLoopData = $sesion->eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row schedule-item">
    <div class="col-md-2">
        <h4>Tema del Evento</strong></h4>
    </div>
    <div class="col-md-10">
        <h4><?php echo e($evento->tema); ?></h4>
        <h5><?php echo e($evento->descripcion); ?></h5>

        <?php if($evento->ponencia != null): ?>
            <?php $__empty_1 = true; $__currentLoopData = $evento->ponencia->ponentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ponente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <h5><strong>Ponente: </strong><time><?php echo e($ponente->nombre); ?></time><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h5><strong>Ponente: </strong><time>Ninguno</time><br>
            <?php endif; ?>
        <?php else: ?>
            <h5><strong>Moderador: </strong><time><?php echo e($evento->concurso->moderador); ?></time><br>
        <?php endif; ?>

        <strong>Hora de Inicio:</strong><time><?php echo e($evento->sesionEvento->hora_inicio); ?></time></h5>
        <a href="#" class="btn btn-outline-dark">Confirmar Participación</a>
        <?php if(auth()->guard()->check()): ?>
            <?php if(session('isAdmin')): ?>
                <?php if($evento->ponencia == null): ?>
                    <a href="<?php echo e(route('concurso.editar', $evento)); ?>" class="btn btn-outline-info"><i  class="glyphicon glyphicon-pencil"></i> Editar Concurso</a><br>
                <?php else: ?>
                    <a href="<?php echo e(route('ponencia.editar', $evento)); ?>" class="btn btn-outline-info"><i  class="glyphicon glyphicon-pencil"></i> Editar Ponencia</a><br>
                <?php endif; ?>
               
                <form action="<?php echo e(route('sesion.quitar_evento')); ?>"  method="POST">
                        <?php echo csrf_field(); ?>
                    <input type="hidden" name="id_sesion" value="<?php echo e($sesion->id); ?>">
                    <input type="hidden" name="id_evento" value="<?php echo e($evento->id); ?>">
                <br><button type="submit" class="btn btn-outline-danger"><i  class="glyphicon glyphicon-remove"></i>Quitar evento</button>

                    <!--<a href="#" class="btn btn-outline-danger" onclick="this.closest('form').submit()"><i  class="glyphicon glyphicon-pencil"></i> Eliminar Ponencia</a><br>-->
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.secondary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\computerscience\resources\views/evento/show.blade.php ENDPATH**/ ?>