<!DOCTYPE html>
<html lang="en">
<head>
    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/header.css')); ?>"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/schedule.css')); ?>"> -->
    <!-- Main Stylesheet File -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">

  <!-- Favicons -->
  <link href="img/placeholder.ico" rel="icon">
  <!-- <link href="img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
  <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css"> -->


  <!-- Libraries CSS Files -->
  <!-- <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet"> -->
  <!-- <link href="<?php echo e(asset('lib/animate/animate.min.css')); ?>" rel="stylesheet"> -->
  <!-- <link href="<?php echo e(asset('lib/venobox/venobox.css')); ?>" rel="stylesheet"> -->
  <!-- <link href="<?php echo e(asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet"> -->
  <!-- <link rel="stylesheet" href="<?php echo e(URL::asset('css/owl.css')); ?>" /> -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" />
  <title><?php echo $__env->yieldContent('title'); ?></title> 
</head>
<body>


  <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <!-- Uncomment below if you prefer to use a text logo -->
        <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
       
        <a href="#intro" class="scrollto"><img src="<?php echo e(URL::asset('/img/logo.png')); ?>" alt="" title=""></a>
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro">Edición</a></li>
          <li><a href="#schedule">Sesiones</a></li>
          <li><a href="#venue">Buscar evento</a></li>
          <li class="block"> 
            <form action="<?php echo e(route('buscar')); ?>" method="POST">
                <input  class="input" name="tema" placeholder="Tema">
            </form>
          </li>
          <?php if(auth()->guard()->check()): ?>
          <li>
              <a href="<?php echo e(route('logout')); ?>" class="about-btn-left scrollto">Cerrar Sesión</a>
            </li>
          <?php else: ?>
          <li>
          <a href="<?php echo e(route('login')); ?>" class="about-btn-left scrollto">Iniciar sesion</a>
            <!-- <a href="<?php echo e(route('login')); ?>">
              <button class="button-left" type="submit">Login</button>
            </a> -->
          </li>
          <li>
            <a href="<?php echo e(route('participante.create')); ?>" class="about-btn-right "> Registrate
              <!-- <button class="Main__Header-button" type="submit">Registrate</button> -->
            </a>

          </li>
          <?php endif; ?>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

 <!--==========================
      About Section
    ============================-->
<section id="about">
<div class="container">
<br><br><br><br><br>
<?php echo $__env->yieldContent('detalles_programas'); ?>
</div>
</section>



    <!--==========================
      Schedule Section
    ============================-->
    <section id="schedule" class="section-with-bg">
      <div class="container wow fadeInUp">
        <div class="section-header">
          
        <h2><?php echo $__env->yieldContent('header'); ?></h2>
          <?php $__env->startSection('descripcion_programa'); ?>
          <p>Aquí está nuestro calendario de eventos</p>
          <?php echo $__env->yieldSection(); ?>
          <br>
          <center>
          <?php echo $__env->yieldContent('boton_crear'); ?>
          </center>
        </div>

        <h3 class="sub-heading">¡El Evento ya comenzó!</h3>

        <div class="tab-content row justify-content-center">

          <!-- Schdule Day 1 -->
          <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">



          
            <?php echo $__env->yieldContent('sesiones'); ?>
            <?php echo $__env->yieldContent('eventos'); ?>
            <?php echo $__env->yieldContent('info_ponentes'); ?>
          </div>

</div>

      <br><br><br>

  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>TheEvent</strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- #footer -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('css/app.css')); ?>"></script>

</body>
</html>


<?php /**PATH E:\Xampp\htdocs\computerscience\resources\views/layout/secondary.blade.php ENDPATH**/ ?>