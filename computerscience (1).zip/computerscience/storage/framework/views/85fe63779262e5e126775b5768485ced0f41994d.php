<a href="<?php echo e(route('home.index')); ?>">Volver a Inicio</a>

<div>
<h1>
    Edicion <?php echo e($data['programa'] ->anio_edicion); ?>

</h1>

<?php if(auth()->guard()->check()): ?>
<a href="<?php echo e(route('programa.edit', $data['programa'] ->id )); ?>">Editar Edicion</a>
<?php endif; ?>

<h2><?php echo e($data['programa'] ->nombre); ?></h2>
<br>
descripcion:
<?php echo e($data['programa'] ->descripcion); ?>

<br>
fecha_inicio:
<?php echo e($data['programa'] ->fecha_inicio); ?>

<br>
fecha_fin: <?php echo e($data['programa'] ->fecha_fin); ?>



<h3>Sesiones</h3>

<?php $__currentLoopData = $data['sesion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <button>
        <?php echo e($sesion->fecha); ?>

        <?php echo e($sesion->hora); ?>

        <?php echo e($sesion->enlace_meet); ?>

    </button>

    <?php
    $temp = $data['columns']
    ?>
    <?php $__currentLoopData = $temp[$sesion->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($eventos->tema); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\AppServ\www\computerscience\resources\views/programa/show.blade.php ENDPATH**/ ?>