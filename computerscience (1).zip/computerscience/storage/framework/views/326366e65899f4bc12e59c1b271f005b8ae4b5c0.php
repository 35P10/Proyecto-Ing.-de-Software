
<?php $__env->startSection('header', 'Sesiones del Programa'); ?>

<?php $__env->startSection('boton_crear'); ?>
<a href="<?php echo e(route('participante.create')); ?>" class="about-btn-right"><i  class="glyphicon glyphicon-plus"></i> Nueva Sesión</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('detalles_programas'); ?>
<div class="row">
        <div class="col-lg-6">
            <h2>Edición <?php echo e($programa->anio_edicion); ?> - <?php echo e($programa->nombre); ?></h2>
            <p><?php echo e($programa->descripcion); ?></p>
        </div>
        <div class="col-lg-3">
            <h3>Lugar:</h3>
            <p>Universidad Nacional de San Agustin, Arequipa</p>
        </div>
        <div class="col-lg-3">
            <h3>Duración</h3>
            <p>Inicio:<br><?php echo e($programa->fecha_inicio); ?></p>
            <p>Fin:<br><?php echo e($programa->fecha_fin); ?></p>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sesiones'); ?>
<?php $__currentLoopData = $programa->sesiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row schedule-item">
<div class="col-md-2">
    <h5><strong>Hora de Inicio:</strong> <time><?php echo e($sesion->hora_inicio); ?></time><br>
    <strong>Hora de Finalización:</strong> <time><?php echo e($sesion->hora_final); ?></time></h5>
</div>
<div class="col-md-10">
    <h4>Fecha: <span> <a><?php echo e($sesion->fecha); ?></a></span></h4>
    <h4>Link: <span> <a href="#" target="_blank"><?php echo e($sesion->enlace_meet); ?></a></span></h5>
    <a href="<?php echo e(route('sesion.show',$sesion->id)); ?>" class="btn btn-outline-dark">Ver Eventos</a>
    <a href="#" class="btn btn-outline-info"><i  class="glyphicon glyphicon-pencil"></i> Editar Sesión</a>
    <a href="#" class="btn btn-outline-danger"><i  class="glyphicon glyphicon-remove"></i> Eliminar Sesión</a>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.secondary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\computerscience\resources\views/sesion/show3.blade.php ENDPATH**/ ?>