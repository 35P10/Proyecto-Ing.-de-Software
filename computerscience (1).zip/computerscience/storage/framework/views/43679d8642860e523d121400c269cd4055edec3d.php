
<?php $__env->startSection('header', 'Creando Nuevo Evento - Ponencia'); ?>

<?php $__env->startSection('descripcion', 'Llena el siguiente formulario.'); ?>

<?php $__env->startSection('nueva_ponencia'); ?>
<div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">
<div class="container">
	<form action="#" method ="POST" enctype="multipart/form-data">
		<div class="col-md-6">
			<label for="tema">Tema</label>
			<div class="form-group">
				<input type="text" placeholder="Tema de la Ponencia" required="" id="tema" size="72" name="tema">
				<i  class="glyphicon glyphicon-font"></i>
			</div>
			<label for="descripcion">Descripción</label>
			<div class="form-group">
				<textarea class="form-control" id="Descrioción de la Ponencia" name="descripcion" rows="10" cols="480" ></textarea>
				<i  class="glyphicon glyphicon-align-justify" ></i>
			</div>	   
		</div>
		<div class="col-md-6">
            <label for="ponente">Ponente</label>
			<div class="form-group">
				<select class="form-control" name="ponente" id="ponente">
					<option value="">Elegir Ponente</option>
						<option value="Marca1">
					</option>
				</select>
                <center><br><a href="#" class="btn btn-outline-dark">Crear nuevo ponente</a></center>
			</div>
			<label for="enlace_meet">Link de la presentación: </label>
			<div class="form-group">
				<input type="text" placeholder="Ej: https://www.academia.edu/35954984/SQL_Transactions" size="72" required="" id="enlace_meet" name="enlace_meet" value="" >
				<i  class="glyphicon glyphicon-link"></i>
			</div>
            <label for="hora_inicio">Hora de Inicio: </label>
			<div class="form-group">
				<input type="text" placeholder="Ej: 8:40" required="" id="hora_inicio" name="hora_inicio" size="72" value="" >
				<i  class="glyphicon glyphicon-time"></i>
			</div>
		</div>
	</div>
	<div class="col-md-12 ">
		<center>
            <button type="submit" class="about-btn-right">Guardar</button>
		</center>
	</div>
    </form>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.third', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\computerscience\resources\views/evento/create-ponencia.blade.php ENDPATH**/ ?>