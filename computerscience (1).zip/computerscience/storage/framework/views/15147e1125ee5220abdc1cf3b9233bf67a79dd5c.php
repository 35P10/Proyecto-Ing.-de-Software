
<?php $__env->startSection('title', 'La Semana de la Computación'); ?>

<!-- Interfaz de Ponentes en Inicio -->
<?php $__env->startSection('ponentes'); ?>
<?php $__currentLoopData = $ponentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ponente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-6">
    <div class="speaker">
        <img src="../../../img/speakers/1.jpg" alt="Speaker 1" class="img-fluid">
            <div class="details">
                <h3><a href="speaker-details.html"><?php echo e($ponente->nombre); ?></a></h3>
                <p><?php echo e($ponente->grado_academico); ?></p>
                <p><strong>Especialidad: </strong><?php echo e($ponente->especialidad); ?></p>
                <div class="social">
                    <a href="<?php echo e(route('ponente.mostrar',$ponente->dni)); ?>" class="btn btn-outline-light">Ver más</a>
                </div>
            </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<!-- Interfaz de Ediciones_programas en Inicio -->
<?php $__env->startSection('ediciones_programas'); ?>
<?php $__currentLoopData = $data['edicion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row schedule-item">
    <div class="col-md-2">
        <br>
        <h5><strong>Inicio:</strong>        
        <date><?php echo e($edicion->fecha_inicio); ?></date><br>
        <strong>Fin:</strong> <date><?php echo e($edicion->fecha_fin); ?></date></h5>
    </div>
    <div class="col-md-10">
        <h4>Edición <?php echo e($edicion->anio_edicion); ?> - <span> <a><?php echo e($edicion->nombre); ?></a></span></h4>
        <h5><?php echo e($edicion->descripcion); ?></h5>
        <a href="<?php echo e(route('programa.show',$edicion->id)); ?>" class="btn btn-outline-dark">Ver Sesiones</a>
        <?php if(auth()->guard()->check()): ?>
        <?php if(session('isAdmin')): ?>
            <a href="<?php echo e(route('programa.edit',$edicion->id )); ?>" class="btn btn-outline-info"><i  class="glyphicon glyphicon-pencil"></i> Editar Programa</a>
            <form action="<?php echo e(route('programa.destroy',$data['programa']->id)); ?>"  method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>  
                <button type="submit" class="btn btn-outline-danger"><i  class="glyphicon glyphicon-remove"></i> Eliminar Programa</button> <br>
            </form>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\computerscience\resources\views/home/index.blade.php ENDPATH**/ ?>