<!DOCTYPE html>
<html lang="en">
<head>
    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">


    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/header.css')); ?>"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/schedule.css')); ?>"> -->
    <!-- Main Stylesheet File -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>">

  <!-- Favicons -->
  <link href="img/placeholder.ico" rel="icon">
  <!-- <link href="img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- <link rel="stylesheet" href="owlcarousel/owl.carousel.min.css">
  <link rel="stylesheet" href="owlcarousel/owl.theme.default.min.css"> -->


  <!-- Libraries CSS Files -->
  <!-- <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet"> -->
  <!-- <link href="<?php echo e(asset('lib/animate/animate.min.css')); ?>" rel="stylesheet"> -->
  <!-- <link href="<?php echo e(asset('lib/venobox/venobox.css')); ?>" rel="stylesheet"> -->
  <!-- <link href="<?php echo e(asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet"> -->
  <!-- <link rel="stylesheet" href="<?php echo e(URL::asset('css/owl.css')); ?>" /> -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('lib/owlcarousel/assets/owl.carousel.min.css')); ?>" />
  <title><?php echo $__env->yieldContent('title'); ?></title> 
</head>
<body>


  <!--==========================
    Header
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <!-- Uncomment below if you prefer to use a text logo -->
        <!-- <h1><a href="#main">C<span>o</span>nf</a></h1>-->
       
        <a href="#intro" class="scrollto"><img src="img/logo.png" alt="" title=""></a>
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#intro">Inicio</a></li>
          <li><a href="#speakers">Ponentes</a></li>
          <li><a href="#schedule">Edicion</a></li>
          <li><a href="#venue">Buscar evento</a></li>
          <li class="block"> 
            <form action="<?php echo e(route('buscar')); ?>" method="POST">
                <input  class="input" name="tema" placeholder="Tema">
            </form>
          </li>
          <li>
          <a href="<?php echo e(route('login')); ?>" class="about-btn-left scrollto">Iniciar sesion</a>
            <!-- <a href="<?php echo e(route('login')); ?>">
              <button class="button-left" type="submit">Login</button>
            </a> -->
          </li>
          <li>
            <a href="<?php echo e(route('participante.create')); ?>" class="about-btn-right "> Registrate
              <!-- <button class="Main__Header-button" type="submit">Registrate</button> -->
            </a>

          </li>
          
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->
  <!--==========================
    Intro Section
  ============================-->
  <section id="intro">
    <div class="intro-container wow fadeIn">
      <h1 class="mb-4 pb-0">La conferencia anual de <br><span>Programacion</span> </h1>
      <p class="mb-4 pb-0">10-12 Diciembre,Ciencia de la Computacion, UNSA</p>
      <a href="https://www.youtube.com/watch?v=wHEpjKpsqco&t=3s" class="venobox play-btn mb-4" data-vbtype="video"
        data-autoplay="true"></a>
      
      <a href="<?php echo e(route('participante.create')); ?>" class="about-btn scrollto">Registrate Aqui</a>
    </div>
  </section>

  <main id="main">




 <!--==========================
      About Section
    ============================-->
    <section id="about">
      <div class="container">
        <div class="row">
          <div class="col-lg-6">
            <h2>Sobre el evento</h2>
            <p>La Semana de la Computación es un Evento organizado por la escuela Profesional de Ciencia de la Computación
               de la Universidad Nacional de San Agustín en el que se exponen trabajos de estudiantes y docentes, 
               se dan charlas de invitados externos, se realiza un concurso de programación y algunas actividades 
               de confraternización.</p>
          </div>
          <div class="col-lg-3">
            <h3>Donde</h3>
            <p>Universidad Nacional de San Agustin , Arequipa</p>
          </div>
          <div class="col-lg-3">
            <h3>Cuando</h3>
            <p>Lunes a miercoles<br>10-12 Diciembre</p>
          </div>
        </div>
      </div>
    </section>



    <!--==========================
      Speakers Section
    ============================-->
    <section id="speakers" class="wow fadeInUp">09
      <div class="container">
        <div class="section-header">
          <h2>Ponentes del evento</h2>
          <p>Estos son algunos de nuestros ponentes</p>
        </div>

        <div class="row">
          <?php echo $__env->yieldContent('ponentes'); ?>

    
        </div>
        </div>
      </div>

    </section>


     <!--==========================
      Schedule Section
    ============================-->
    <section id="schedule" class="section-with-bg">
      <div class="container wow fadeInUp">
        <div class="section-header">
          <h2>Programa</h2>
          <?php $__env->startSection('descripcion_programa'); ?>
          <p>Aquí está nuestro calendario de eventos</p>
            <?php echo $__env->yieldSection(); ?>
        </div>

        <!-- <ul class="nav nav-tabs" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" href="#day-1" role="tab" data-toggle="tab">Day 1</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-2" role="tab" data-toggle="tab">Day 2</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#day-3" role="tab" data-toggle="tab">Day 3</a>
          </li>
        </ul> -->

        <h3 class="sub-heading">¡El Evento ya comenzó!</h3>

        <div class="tab-content row justify-content-center">

          <!-- Schdule Day 1 -->
          <div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">

            <div class="row schedule-item">
              <div class="col-md-2"><time>09:30 AM</time></div>
              <div class="col-md-10">
                <h4>Registracion</h4>
                <!-- <p>Fugit voluptas iusto maiores temporibus autem numquam magnam.</p> -->
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>10:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="../../img/speakers/1.jpg" alt="Brenden Legros">
                </div>
                <h4>2021  Semana de la Computacion:<span> <a> Una mirada al futuro</a></span></h4>
               
              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>11:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="../../img/speakers/2.jpg" alt="Hubert Hirthe">
                </div>
                <h4>2021  Semana de la Computacion:<span> <a> Descubriendo el futuro</a></span></h4>

              </div>
            </div>

             <div class="row schedule-item">
              <div class="col-md-2"><time>12:00 AM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="../../img/speakers/3.jpg" alt="Cole Emmerich">
                </div>
                <h4>2021  Semana de la Computacion:<span> <a> Imaginando Algoritmos</a></span></h4>

             </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>02:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="../../img/speakers/4.jpg" alt="Jack Christiansen">
                </div>
                <h4>2021  Semana de la Computacion:<span> <a> Trabajando por nuestros sueños</a></span></h4>

              </div>
            </div>

            <div class="row schedule-item">
              <div class="col-md-2"><time>03:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="../../img/speakers/5.jpg" alt="Alejandrin Littel">
                </div>
                <h4>2021  Semana de la Computacion:<span> <a> Hello World</a></span></h4>
              </div>
            </div>
<!--
            <div class="row schedule-item">
              <div class="col-md-2"><time>04:00 PM</time></div>
              <div class="col-md-10">
                <div class="speaker">
                  <img src="../../img/speakers/6.jpg" alt="Willow Trantow">
                </div>
                <h4>Quo qui praesentium nesciunt <span>Willow Trantow</span></h4>
                <p>Voluptatem et alias dolorum est aut sit enim neque veritatis.</p>
              </div> -->
            </div>

          </div>
          <!-- End Schdule Day 1 -->

  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <!-- <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <img src="img/logo.png" alt="TheEvenet">
            <p>In alias aperiam. Placeat tempore facere. Officiis voluptate ipsam vel eveniet est dolor et totam porro. Perspiciatis ad omnis fugit molestiae recusandae possimus. Aut consectetur id quis. In inventore consequatur ad voluptate cupiditate debitis accusamus repellat cumque.</p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="#">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="fa fa-angle-right"></i> <a href="#">Home</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">About us</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Services</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="fa fa-angle-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>

          </div>

        </div>
      </div>
    </div> -->
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>TheEvent</strong>. All Rights Reserved
      </div>
    </div>
  </footer><!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>


<!-- <div class="Main__Header">
    <div className="Main__Header-img">
      <a href="<?php echo e(route('participante.create')); ?>">
        <img src="../../images/logo.png" alt="TheEvenet" />
      </a>     
    </div>  
   <div class="Main__Header-navbar">     
     <ul >
       <li><a href="#servicios"> Inicio</a></li>
       <li><a href="#nosotros">Edicion</a></li>
       <li><a href="#work">Buscar evento</a></li>
       <li class="block"> 

        <form action="<?php echo e(route('buscar')); ?>" method="POST">
            <input  class="input" name="tema" placeholder="Tema">
        </form>
       </li>
     </ul>
   </div>
   <a href="<?php echo e(route('login')); ?>">
      <button class="button-left" type="submit">Login</button>
    </a>
   <a href="<?php echo e(route('participante.create')); ?>">
      <button class="Main__Header-button" type="submit">Registrate</button>
    </a>
</div> -->

 

  


<!-- <div class="Services">
    <div class="Services-bg">
        <img src="../../images/fondo.jpg" alt="fondo"/>
        <div class="info">
            <h1>LA CONFERENCIA ANUAL DE  <strong >PROGRAMACIÓN</strong> </h1>
            <h4>10-12 Diciembre, <strong >Ciencia de la Computación</strong>,UNSA - Arequipa</h4>
            <a  href="<?php echo e(route('participante.create')); ?>">
            <button>Registrate Aqui</button>
            </a>          
        </div>        
    </div>
      
</div> -->

  



<!-- 
<h1>
    Inicio
</h1>

<h2>
    Edicion
</h2>

<?php $__currentLoopData = $_edicion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
    <a href="<?php echo e(route('programa.show',$edicion->anio_edicion)); ?>"><?php echo e($edicion->anio_edicion); ?>

    <?php echo e($edicion->nombre); ?></a><br>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
 <h2>
     Buscar evento
 </h2>

 <a href="<?php echo e(route('buscar')); ?>">Buscars</a>


 <form action="<?php echo e(route('buscar')); ?>" method="POST">
    <input name="tema" placeholder="Tema">
    <button type="submit">Icon</button>
 </form>

 <a href="<?php echo e(route('login')); ?>">Login</a>
 <a href="<?php echo e(route('participante.create')); ?>">Register</a> -->





<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script type="text/javascript" src="<?php echo e(asset('css/app.css')); ?>"></script>

</body>
</html>


<?php /**PATH C:\AppServ\www\computerscience\resources\views/layout.blade.php ENDPATH**/ ?>