<h1>
    sesion
</h1>
<header>
    <a href="<?php echo e(route('programa.show',$data['sesion']->id_programa)); ?>">Volver</a>
</header>
<p>Dia: <?php echo e($data['sesion']->fecha); ?></p>
<p>Hora: <?php echo e($data['sesion']->hora_inicio); ?> - <?php echo e($data['sesion']->hora_final); ?></p>
<p>Enlace de reunion: <?php echo e($data['sesion']->enlace_meet); ?></p>

<h3>
    eventos
</h3>
<?php $__currentLoopData = $data['evento']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($evento->hora_inicio); ?></p>
        <p><?php echo e($evento->tema); ?></p>
        <a>Quitar evento</a>
        
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 
<button> + Anhadir evento </button>
<form action="#" method="POST">
    <input type="hidden" name="id_programa" value="<?php echo e($data['sesion']->id_programa); ?>"> 
    <label for='fecha'>fecha</label>
    <input name='fecha' type='date'>
    <br>
    <label for='hora_inicio'>hora inicio</label>
    <input name='hora_inicio' type='time'>
    <br>
    <label>Descripcion</label><br>
    <textarea placeholder="descripcion"></textarea>
    <br>
    <label for='enlace_meet'>enlace de reunion</label>
    <input name='enlace_meet'>
    <br>
    <button type='submit'>Crear</button>
    
</form>
<?php /**PATH C:\AppServ\www\computerscience\resources\views/sesion/show2.blade.php ENDPATH**/ ?>