<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ponente</title>
</head>
<body>
    <h1>Ponente</h1>
    <h2><?php echo e($ponente->dni); ?></h2>
</body>
</html><?php /**PATH C:\AppServ\www\computerscience\resources\views/ponente/show-ponente.blade.php ENDPATH**/ ?>