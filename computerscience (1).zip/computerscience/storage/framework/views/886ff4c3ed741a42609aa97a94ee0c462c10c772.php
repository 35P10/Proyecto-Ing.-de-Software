
<?php $__env->startSection('header', 'Editar Sesion'); ?>

<?php $__env->startSection('descripcion', 'Edita el siguiente formulario.'); ?>

<?php $__env->startSection('nuevo_concurso'); ?>
<div role="tabpanel" class="col-lg-9 tab-pane fade show active" id="day-1">
<div class="container">
	<form action="<?php echo e(route('sesion.update',$data['sesion']->id)); ?>"  method ="POST" enctype="multipart/form-data">
	<?php echo csrf_field(); ?>

    <?php echo e(method_field('PUT')); ?>

		<div class="col-md-6">
			<label for="fecha">D&iacute;a:</label>
			<div class="form-group">
				<input type="date" required="" id="fecha" name="fecha"  value="<?php echo e($data['sesion']->fecha); ?>">
				<i  class="glyphicon glyphicon-font"></i>
			</div>   
		</div>
		<div class="col-md-6">
            <label for="hora_inicio">Hora inicio </label>
			<div class="form-group">
				<input type="time"   required="" id="hora_inicio" name="hora_inicio" value="<?php echo e($data['sesion']->hora_inicio); ?>" >
				<i  class="glyphicon glyphicon-time"></i>
			</div>
            <label for="hora_final">Hora de finalización </label>
			<div class="form-group">
				<input type="time" required="" id="hora_final" name="hora_final"  value="<?php echo e($data['sesion']->hora_final); ?>" >
				<i  class="glyphicon glyphicon-sort-by-order"></i>
			</div>
			<label for="enlace_meet">Enlace de reunion</label>
			<div class="form-group">
				<input type="text" required="" id="enlace_meet" name="enlace_meet" value="<?php echo e($data['sesion']->enlace_meet); ?>" >
				<i  class="glyphicon glyphicon-sort-by-order"></i>
			</div>
            
		</div>
	</div>
	<div class="col-md-12 ">
		<center>
            <br><button type="submit" class="about-btn-right">Guardar</button>
		</center>
	</div>
    </form>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.third', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\computerscience\resources\views/sesion/edit.blade.php ENDPATH**/ ?>