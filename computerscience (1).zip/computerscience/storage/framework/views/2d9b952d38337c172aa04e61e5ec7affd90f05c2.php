<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>


<header style="display:block; background-color:green">
    <nav>
    <h1>
        Inicio
    </h1>
        <form action="<?php echo e(route('buscar')); ?>" method="POST">
            <input name="tema" placeholder="Buscar por Tema">
            <button type="submit">Icon</button>
        </form>
        <a href="<?php echo e(route('login')); ?>">Login</a>
        <a href="<?php echo e(route('participante.create')); ?>">Register</a>

        <!--botones exclusivos del administrador -->
        <a href="<?php echo e(route('programa.create')); ?>">Crear Programa</a>
        <a href="<?php echo e(route('sesion.create')); ?>">Crear Sesion</a>
        <a href="#">Crear evento</a>
        <a href="#">Registrar ponente</a>
    </nav>

    <?php if($message = Session::get('success')): ?>
        <div>
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <section>
        <h2>
            Ediciones
        </h2>  
        <select>
        <?php $__currentLoopData = $data['edicion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
        <option><a href="<?php echo e(route('programa.show',$edicion->id)); ?>"><?php echo e($edicion->anio_edicion); ?> <?php echo e($edicion->nombre); ?></a></option>
        <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <?php $__currentLoopData = $data['edicion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
        <a href="<?php echo e(route('programa.show',$edicion->id)); ?>"><?php echo e($edicion->anio_edicion); ?>

            <?php echo e($edicion->nombre); ?></a><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
 </header>
 <main style="display:block; background-color:red"> <!--main -->
    <section> <!--session edicion mas reciente -->
        <div style="display:block; background-color:peachpuff">  <!-- titulo -->
            <h1>
                Ultima Edicion: <?php echo e($data['programa'] ->anio_edicion); ?>

            </h1>

            <h2><?php echo e($data['programa'] ->nombre); ?></h2>
            <br>
        </div>
        <div style="display:block; background-color:thistle"> <!--informacion del programa -->
            descripcion:
            <?php echo e($data['programa'] ->descripcion); ?>

            <br>
            fecha_inicio:
            <?php echo e($data['programa'] ->fecha_inicio); ?>

            <br>
            fecha_fin:
            <?php echo e($data['programa'] ->fecha_fin); ?>


        </div>
        <div style="background-color:burlywood">
            <h3>Sesiones</h3>

            <?php $__currentLoopData = $data['sesion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button style="display:block; background-color:peru"> <!--informacion de cada sesion -->
                    <?php echo e($sesion->fecha); ?>

                    <?php echo e($sesion->hora); ?>

                    <?php echo e($sesion->enlace_meet); ?>

                </button>
                <section style="background-color:lemonchiffon"> <!--eventos de cada sesion -->
                    <!--ignorar -->
                    <?php 
                    $temp = $data['columns'] 
                    ?> 
                    <!--ignorar -->

                    <?php $__currentLoopData = $temp[$sesion->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a><p><?php echo e($eventos->hora_inicio); ?> <?php echo e($eventos->tema); ?></p></a> <!--se puede aplicar estilos -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section style="width:100% ;background-color:salmon;"> <!--Seccion de ponentes : rojo -->
        <h3>Ponentes</h3>
        <div style="display:flex; text-align:center;">
            <?php $__currentLoopData = $data['ponentes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ponente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="width:30% ;background-color:lightblue;">  <!--celeste -->
                <p><?php echo e($ponente->nombre); ?></p>
                <p><?php echo e($ponente->grado_academico); ?></p>
                <p><?php echo e($ponente->especialidad); ?></p>
                <p><?php echo e($ponente->descripcion); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
 </main> 

 <header style="display:block; background-color:blue"> <!--header -->
     <p>Ing. Software</p>
 </header>

 </body>
</html>
<?php /**PATH C:\AppServ\www\computerscience\resources\views/home/index2.blade.php ENDPATH**/ ?>